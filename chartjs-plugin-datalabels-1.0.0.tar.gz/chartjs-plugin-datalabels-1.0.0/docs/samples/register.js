import {plugins} from 'chart.js';
import plugin from '../../dist/chartjs-plugin-datalabels.js';

plugins.register(plugin);
