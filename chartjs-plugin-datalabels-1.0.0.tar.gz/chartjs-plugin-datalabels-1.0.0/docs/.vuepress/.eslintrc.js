module.exports = {
  parserOptions: {
    ecmaVersion: 2018
  }
};
