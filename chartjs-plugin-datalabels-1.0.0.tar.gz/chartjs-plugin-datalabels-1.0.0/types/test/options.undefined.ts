import {Chart} from 'chart.js';

const chart = new Chart('id', {
  data: {
    datasets: [
      {
        // no datalabels options
      }
    ]
  },
  options: {
    plugins: {
      // no datalabels options
    }
  }
});
